import initFontAwesome from "./utils/initFontAwesome";

// Init fonts
initFontAwesome();

// Test mocks
require("jest-fetch-mock").enableMocks();
